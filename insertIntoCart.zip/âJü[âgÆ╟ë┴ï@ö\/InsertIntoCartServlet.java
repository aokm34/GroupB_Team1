/*
 * カートに商品を追加する機能に関する処理を行うサーブレットクラス
 * 作成日：2022年6月9日
 * 作成者：本多祐香子
 */
package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.UniformDAO;

public class InsertIntoCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラー用変数の生成
		String error = "";
		String cmd = "";

		// セッションオブジェクトの生成
		HttpSession session = request.getSession();

		try {
			// セッションからUserオブジェクトを取得
			User user = (User) session.getAttribute("user");

			if (user == null) {
				error = "セッション切れの為、カートに追加出来ません。 ";
				cmd = "logout";
				return;
			}

			// パラメータ取得
			String id = (String) request.getParameter("userid");
			String strQuantity = (String) request.getParameter("quantity");

			// UniformDAOをインスタンス化し、selectByIdメソッドを呼び出す
			UniformDAO uniDaoObj = new UniformDAO();
			Uniform uniform = uniDaoObj.selectById(id);

			// OrderListをインスタンス化し、各変数の値を設定
			OrderList order = new OrderList();
			order.setUniformId(id);
			order.setUniformName(uniform.getName());
			order.setPrice(uniform.getPrice());

			// 数量の入力値チェック
			int quantity;
			try {
				quantity = Integer.parseInt(strQuantity);
			} catch (NumberFormatException e) {
				error = "数量には整数値を入力してください。";
				cmd = "list";
				return;
			}

			// 注文数が在庫数を上回る場合はエラー
			if (quantity > uniform.getStock()) {
				error = "在庫不足の為、ご指定の数量を用意できません。";
				cmd = "list";
				return;
			}
			order.setQuantity(quantity);

			// OrderListオブジェクトをリクエストスコープに登録
			request.setAttribute("order", order);

			// セッションからorder_listのList配列を取得
			ArrayList<OrderList> list = (ArrayList<OrderList>) session.getAttribute("order_list");

			// 取得できなかった場合は新規で作成
			if (list == null) {
				list = new ArrayList<OrderList>();
			}

			// OrderオブジェクトをList配列に追加し、セッションスコープに登録
			list.add(order);
			session.setAttribute("order_list", list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、カートに追加は出来ません。";
			cmd = "logout";
		} finally {

			if (error.equals("")) {
				request.getRequestDispatcher("/view/insertIntoCart.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}

	}

}
