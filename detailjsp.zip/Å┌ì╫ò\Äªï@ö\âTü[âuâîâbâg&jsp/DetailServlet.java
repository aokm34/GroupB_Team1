/*
 * 商品詳細表示機能に関する処理を行うサーブレットクラス
 * 作成日：2022年6月21日
 * 作成者：本多祐香子
 */

package servlet;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.Uniform;
import dao.UniformDAO;

public class DetailServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラー用変数の生成
		String error = "";
		String cmd = "";

		try {
			// DAOオブジェクトの生成
			UniformDAO uniDaoObj = new UniformDAO();

			// uniformidとcmd情報を受け取る
			cmd = (String) request.getParameter("cmd");
			String id = (String) request.getParameter("uniformid");

			// 商品情報を検索し、戻り値としてUniformオブジェクトを取得する
			Uniform uniform = uniDaoObj.selectById(id);

			// 対象商品がない場合のエラー処理
			if (uniform.getId() == null) {

				if (cmd.equals("detail")) {
					error = "表示対象の商品が存在しない為、詳細画面は表示できませんでした。";
					cmd = "list";
					return;
				} else if (cmd.equals("update")) {
					error = "更新対象の商品が存在しない為、変更画面は表示できませんでした。";
					cmd = "list";
					return;
				}

			}

			request.setAttribute("uniform", uniform);

		} catch (IllegalStateException e) {

			if (cmd.equals("detail")) {
				error = "DB接続エラーの為、商品詳細は表示できませんでした。";
				cmd = "logout";
			} else if (cmd.equals("update")) {
				error = "DB接続エラーの為、変更画面は表示できませんでした。";
				cmd = "logout";
			}
		} finally {

			if (error.equals("")) {
				if (cmd.equals("detail")) {
					request.getRequestDispatcher("/view/detail.jsp").forward(request, response);
				} else {
					request.getRequestDispatcher("/view/update.jsp").forward(request, response);
				}
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}

	}

}
