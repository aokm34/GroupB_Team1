/*
 * DAOクラス（注文履歴情報）
 * 作成日：2022年6月21日
 * 作成者：伊藤瑠玖
 */
package dao;

import java.sql.*;
import java.util.ArrayList;
import bean.OrderList;

public class OrderListDAO {
	/**
	 * JDBCドライバ内部のDriverクラスパス
	 */
	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	/**
	 * 接続するMySQLデータベースパス
	 */
	private static final String URL = "jdbc:mysql://localhost/uniformdb";
	/**
	 * データベースのユーザー名
	 */
	private static final String USER = "root";
	/**
	 * データベースのパスワード
	 */
	private static final String PASSWD = "root123";

	/**
	 * フィールド変数の情報を基に、DB接続をおこなうメソッド
	 *
	 * @return データベース接続情報]
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/**
	 * DBのユニフォーム情報を格納するorderlistテーブルへユニフォーム情報を登録する
	 *
	 * @param orderlist 登録する購入履歴のオブジェクト
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public void insert(OrderList order_list) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "INSERT INTO orderlist VALUES(NULL," + order_list.getCustomerNum() + ",'"
					+ order_list.getUniformId() + "'," + order_list.getQuantity() + "," + order_list.getPrice() + ")";
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**
	 * 引数のIDを基に、注文されたユニフォームの情報をArrayListに格納していくメソッド
	 *
	 * @param id 検索対象のID
	 * @return 検索結果のユニフォーム情報のオブジェクト<br>
	 *         ユニフォーム情報が見つからなかった場合は、オブジェクト内部の値が初期値の状態で返される
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public ArrayList<OrderList> selectByCustomerNum(int customerNum) {
		ArrayList<OrderList> order_list = new ArrayList<OrderList>();
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "SELECT o.uniformID,u.uniform_name,o.quantity,o.price from orderlist o inner join uniforminfo u on o.uniformID=u.uniformID WHERE o.customer_num = "
					+ customerNum;
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				OrderList orderlist = new OrderList();
				orderlist.setUniformId(rs.getString("uniformID"));
				orderlist.setUniformName(rs.getString("uniform_name"));
				orderlist.setQuantity(rs.getInt("quantity"));
				orderlist.setPrice(rs.getInt("price"));
				order_list.add(orderlist);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return order_list;
	}

}
