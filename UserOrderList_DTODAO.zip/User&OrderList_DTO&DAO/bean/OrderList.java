/*
 * DTOクラス（注文情報）
 * 作成日：2022年6月21日
 * 作成者：本多祐香子
 */

package bean;

public class OrderList {

	private int list_num;
	private int order_num;
	private int uniformid;
	private int quantity;
	private int price;

	// コンストラクタ
	public OrderList() {
		this.list_num = 0;
		this.order_num = 0;
		this.uniformid = 0;
		this.quantity = 0;
		this.price = 0;
	}

	// アクセサメソッド
	public int getListNum() {
		return list_num;
	}

	public int getOrderNum() {
		return order_num;
	}

	public int getUniformId() {
		return uniformid;
	}

	public int getQuantity() {
		return quantity;
	}

	public int getPrice() {
		return price;
	}

	public void setListNum(int list_num) {
		this.list_num = list_num;
	}

	public void setOrderNum(int order_num) {
		this.order_num = order_num;
	}

	public void setUniformId(int uniformid) {
		this.uniformid = uniformid;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setPrice(int price) {
		this.price = price;
	}
}
