/*
 * DAOクラス（注文情報）
 * 作成日：2022年6月21日
 * 作成者：本多祐香子
 */
package dao;

import java.sql.*;
import java.util.*;
import bean.OrderList;

public class OrderListDAO {

	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/mybookdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public static void main(String[] args) throws Exception {

		Connection con = getConnection();
		System.out.println("con=" + con);
		con.close();

	}

	public void insert(OrderList order) {

		// SQL文を生成
		String sql = "INSERT INTO orderlist VALUES(NULL," + order.getOrderNum() + "," + order.getUniformId() + ","
				+ order.getQuantity() + "," + order.getPrice() + ")";

		Connection con = null;
		Statement smt = null;

		try {
			con = OrderListDAO.getConnection();
			smt = con.createStatement();

			// SQL文を発行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

}
