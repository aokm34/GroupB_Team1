/*
 * DTOクラス（注文履歴情報）
 * 作成日：2022年6月21日
 * 作成者：伊藤瑠玖
 */
package bean;

public class OrderList {

	/**
	 * 購入履歴のナンバー
	 */
	private int listNum;
	/**
	 * 受注ナンバー
	 */
	private int customerNum;
	/**
	 * 商品番号
	 */
	private String uniformId;
	/**
	 * 数量
	 */
	private int quantity;
	/**
	 * 単価
	 */
	private int price;
	/**
	 * ユニフォームの商品名
	 */
	private String uniformName;

	/**
	 * コンストラクタ<br>
	 */
	public OrderList() {
		this.listNum = 0;
		this.customerNum = 0;
		this.uniformId = null;
		this.quantity = 0;
		this.price = 0;
		this.uniformName = null;
	}

	/**
	 * 購入履歴のナンバーのゲッターセッター
	 */
	public int getListNum() {
		return listNum;
	}

	public void setListNum(int listNum) {
		this.listNum = listNum;
	}

	/**
	 * 受注ナンバーのゲッターセッター
	 */
	public int getCustomerNum() {
		return customerNum;
	}

	public void setCustomerNum(int customerNum) {
		this.customerNum = customerNum;
	}

	/**
	 * 商品番号のゲッターセッター
	 */
	public String getUniformId() {
		return uniformId;
	}

	public void setUniformId(String uniformId) {
		this.uniformId = uniformId;
	}

	/**
	 * 数量のゲッターセッター
	 */
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * 単価のゲッターセッター
	 */
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	/**
	 * 商品名のゲッターセッター
	 */
	public String getUniformName() {
		return uniformName;
	}

	public void setUniformName(String uniformName) {
		this.uniformName = uniformName;
	}

}
