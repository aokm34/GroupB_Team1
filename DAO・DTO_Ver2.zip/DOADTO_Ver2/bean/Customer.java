package bean;

/*
 * DTOクラス（受注者内容）
 * 作成日：2022年6月22日
 * 作成者：櫻田悠雅
 */

public class Customer {

	private int customerNum; // 受注番号
	private String name; // 受注者氏名
	private String adressNum; // 郵便番号
	private String adress; // 住所
	private String email; // メールアドレス
	private String orderDate; // 発注日
	private int sumPrice; // 合計金額
	private String deposit; // 入金状況フラグ(1：未、２：入金済、0：キャンセル）
	private String sending; // 発送状況フラグ(1：未、２：発送準備、3：発送済、0：キャンセル）
	private String bikou; // 備考

	// 引数無しコンストラクタ
	public Customer() {
		this.customerNum = 0;
		this.name = null;
		this.adressNum = null;
		this.adress = null;
		this.email = null;
		this.orderDate = null;
		this.sumPrice = 0;
		this.deposit = null;
		this.sending = null;
		this.bikou = null;
	}

	// 各ゲッター
	public int getCustomerNum() {
		return this.customerNum;
	}

	public String getName() {
		return this.name;
	}

	public String getAdressNum() {
		return this.adressNum;
	}

	public String getAdress() {
		return this.adress;
	}

	public String getEmail() {
		return this.email;
	}

	public String getOrderDate() {
		return this.orderDate;
	}

	public int getSumPrice() {
		return this.sumPrice;
	}

	public String getDeposit() {
		return this.deposit;
	}

	public String getSending() {
		return this.sending;
	}

	public String getBikou() {
		return this.bikou;
	}

	// 各セッター
	public void setCustomerNum(int customerNum) {
		this.customerNum = customerNum;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAdressNum(String adressNum) {
		this.adressNum = adressNum;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public void setEail(String email) {
		this.email = email;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public void setSumPrice(int sumPrice) {
		this.sumPrice = sumPrice;
	}

	public void setDeposit(String deposit) {
		this.deposit = deposit;
	}

	public void setSending(String sending) {
		this.sending = sending;
	}

	public void setBikou(String bikou) {
		this.bikou = bikou;
	}

}
