/*
 * DAOクラス（ユニフォーム情報）
 * 作成日：2022年6月21日
 * 作成者：伊藤瑠玖
 */
package dao;

import java.sql.*;
import java.util.*;

import bean.Uniform;

public class UniformDAO {
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/uniformdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public static void main(String[] args) throws Exception {

		Connection con = getConnection();
		System.out.println("con=" + con);
		con.close();

	}

	/**
	 * DB籍情ユニフォーム情報を格納するuniforminfoテーブルから全ユニフォーム情報を取得する
	 *
	 * @return 全ユニフォーム情報のリスト
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public ArrayList<Uniform> selectAll() {
		Connection con = null;
		Statement smt = null;
		ArrayList<Uniform> uniformList = new ArrayList<Uniform>();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT * FROM uniforminfo ORDER BY uniformId";
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Uniform uniform = new Uniform();
				uniform.setUniformId(rs.getString("uniformID"));
				uniform.setName(rs.getString("uniform_name"));
				uniform.setPrice(rs.getInt("price"));
				uniform.setStock(rs.getInt("stock"));
				uniformList.add(uniform);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return uniformList;
	}

	// 修正ありSQL

	/**
	 * DBのユニフォーム情報を格納するuniforminfoテーブルへユニフォーム情報を登録する
	 *
	 * @param uniform 登録するユニフォーム情報のオブジェクト
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public void insert(Uniform uniform) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "INSERT INTO uniforminfo VALUES('" + uniform.getUniformId() + "','" + uniform.getName() + "',"
					+ uniform.getPrice() + "," + uniform.getStock() + ")";
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// 修正ありSQL文

	/**
	 * 引数のユニフォーム（ID）を基にDBのユニフォーム情報を格納するuniforminfoテーブルから該当ユニフォームデータの削除をおこなう
	 *
	 * @param _id 削除対象のID
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public void delete(String uniformId) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "DELETE FROM uniforminfo WHERE uniformID='" + uniformId + "'";
			smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**
	 * 引数のユニフォームデータを基にDBのユニフォーム情報を格納するuniforminfoテーブルから概要ユニフォームデータの更新処理をおこなう
	 *
	 * @param uniform 更新するユニフォーム情報のオブジェクト
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public void update(Uniform uniform) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "UPDATE uniforminfo SET uniform_name ='" + uniform.getName() + "', price ="
					+ uniform.getPrice() + ", stock =" + uniform.getStock() + " WHERE uniformID ='"
					+ uniform.getUniformId() + "'";

			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// SQL文の

	/**
	 * 引数のIDを基にDBのユニフォーム情報を格納するuniforminfoテーブルから該当ユニフォームデータの検索をおこなう
	 *
	 * @param id 検索対象のID
	 * @return 検索結果のユニフォーム情報のオブジェクト<br>
	 *         ユニフォーム情報が見つからなかった場合は、オブジェクト内部の値が初期値の状態で返される
	 * @throws IllegalStateException メソッド内部で例外が発生した場合
	 */
	public Uniform selectByUniformId(String uniformId) {
		Uniform uniform = new Uniform();
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "SELECT * FROM uniforminfo WHERE uniformID='" + uniformId + "'";
			ResultSet rs = smt.executeQuery(sql);

			if (rs.next()) {
				uniform.setUniformId(rs.getString("uniformID"));
				uniform.setName(rs.getString("uniform_name"));
				uniform.setPrice(rs.getInt("price"));
				uniform.setStock(rs.getInt("stock"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return uniform;
	}

}
