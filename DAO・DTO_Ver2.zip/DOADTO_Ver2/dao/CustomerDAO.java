package dao;

/*
 * DAOクラス（受注者内容）
 * 作成日：2022年6月22日
 * 作成者：櫻田悠雅
 */

import java.sql.*;
import java.util.*;

import bean.Customer;

public class CustomerDAO {

	// データベース接続情報
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/uniformdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// データベースに接続するメゾッド
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/**
	 * 商品を受注する際に、DBにおいて使用する受注ナンバーを発行するメゾッド
	 *
	 * @return int型 新たな受注ナンバーを発行
	 */
	public int getNewCousomerNum() {

		// DBへ接続準備
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();

			// 新たに登録する受注ナンバーを格納する変数を宣言
			int newCostomerNum = 1;

			// SQL文
			String sql = "SELECT MAX(customer_num) FROM customerinfo";

			// DBへ送り最大値のデータを取得
			ResultSet rs = smt.executeQuery(sql);

			// データがあれば、最も大きい受注ナンバーに数字に1を加える
			while (rs.next()) {
				newCostomerNum = (rs.getInt("MAX(customer_num)") + 1);
			}

			// 登録する新たな受注ナンバーを返す
			return newCostomerNum;

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**
	 * 引数であるCustomer型DTOをDBに登録するメゾッド
	 *
	 * @param cus 各変数にデータを格納したDTOを引数とする
	 */
	public void insertCustomer(Customer cus) {

		Connection con = null;
		Statement smt = null;

		try {

			// データベースに接続する
			con = getConnection();
			// SQL文をDBに送る準備
			smt = con.createStatement();
			String sql = "INSERT INTO customerinfo VALUES (" + cus.getCustomerNum() + ",'" + cus.getName() + "','"
					+ cus.getAdressNum() + "','" + cus.getAdress() + "','" + cus.getEmail() + "',CURDATE(),"
					+ cus.getSumPrice() + ",'" + cus.getDeposit() + "','" + cus.getSending() + "','" + cus.getBikou()
					+ "')";

			// SQL文をDBに送る
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**
	 * 受注ナンバーを使用して、1件の受注内容を全て取得するメゾッド
	 *
	 * @param customerNum DBに検索する際の受注No
	 * @return 取得した顧客データ Customer型オブジェクト
	 */
	public Customer selectByCustamNum(int customerNum) {
		Connection con = null;
		Statement smt = null;

		// 検索された注文者情報を格納するオブジェクト
		Customer cus = new Customer();

		try {

			// データベースに接続する
			con = getConnection();
			// SQL文をDBに送る準備
			smt = con.createStatement();

			// SQL文
			String sql = "SELECT * FROM customerinfo WHERE isbn = " + customerNum;

			// SQL文をDBに送り、その結果を受け取る
			ResultSet rs = smt.executeQuery(sql);

			// 取得データをDTOに格納
			while (rs.next()) {
				cus.setCustomerNum(rs.getInt("customer_num"));
				cus.setName(rs.getString("name"));
				cus.setAdressNum(rs.getString("adress_num"));
				cus.setAdress(rs.getString("adress"));
				cus.setEail(rs.getString("email"));
				cus.setOrderDate(rs.getString("order_date"));
				cus.setSumPrice(rs.getInt("sum_price"));
				cus.setDeposit(rs.getString("deposit"));
				cus.setSending(rs.getString("sending"));
				cus.setBikou(rs.getString("bikou"));

			}

			return cus;

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**
	 * 入金状況を更新するメゾッド
	 *
	 * @param customerNum 変更対象の受注ナンバー
	 * @param newDeposit 変更する新フラグ内容
	 */
	public void updateDeposit(int customerNum, String newDeposit) {
		Connection con = null;
		Statement smt = null;

		String sql = "UPDATE customerinfo SET deposit='" + newDeposit + "' WHERE customer_num=" + customerNum;

		try {

			// データベースに接続する
			con = getConnection();
			// SQL文をDBに送る準備
			smt = con.createStatement();
			// SQL文をDBに送る
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**
	 * 発送状況を変更するメゾッド
	 *
	 * @param customerNum 変更対象の受注ナンバー
	 * @param newSending 変更する新発送フラグ内容
	 */
	public void updateSending(int customerNum, String newSending) {
		Connection con = null;
		Statement smt = null;

		String sql = "UPDATE customerinfo SET sending='" + newSending + "' WHERE customer_num=" + customerNum;

		try {

			// データベースに接続する
			con = getConnection();
			// SQL文をDBに送る準備
			smt = con.createStatement();
			// SQL文をDBに送る
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**
	 * 指定された年月の受注内容を一覧表示する際のメゾッド
	 *
	 * @param year  検索対象の年
	 * @param month 検索対象の月
	 * @return 検索結果ヒットしたCutomer型ArrayList
	 */
	public ArrayList<Customer> selectBySales(String year, String month) {

		Connection con = null;
		Statement smt = null;

		ArrayList<Customer> list = new ArrayList<Customer>();

		try {
			// データベースに接続する
			con = getConnection();
			// SQL文をDBに送る準備
			smt = con.createStatement();

			// 月の数字が一桁である場合は、先頭に0を加える
			if (month.length() == 1) {
				month = "0" + month;
			}

			// SQL文（必要な情報を絞るために指定する）
			String sql = "SELECT customer_num,name,order_date,sum_price,deposit,sending FROM customerinfo WHERE order_date LIKE '"
					+ year + "-" + month + "%'";

			// SQL文をDBに送り、その結果を受け取る
			ResultSet rs = smt.executeQuery(sql);

			// データをDTOに格納し、配列に加える
			while (rs.next()) {
				Customer customer = new Customer();

				customer.setCustomerNum(rs.getInt("customer_num"));
				customer.setName(rs.getString("name"));
				customer.setOrderDate(rs.getString("order_date"));
				customer.setSumPrice(rs.getInt("sum_price"));
				customer.setDeposit(rs.getString("deposit"));
				customer.setSending(rs.getString("sending"));

				list.add(customer);

			}

			return list;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

}
