/*
 * DAOクラス（管理者情報）
 * 作成日：2022年6月21日
 * 作成者：伊藤瑠玖
 */
package bean;

public class OrderHistory {

	/**
	 * 購入履歴のナンバー
	 */
	private int historyNum;
	/**
	 * 受注ナンバー
	 */
	private int orderNum;
	/**
	 * 商品番号
	 */
	private String id;
	/**
	 * 数量
	 */
	private int quantity;
	/**
	 * 単価
	 */
	private int price;

	/**
	 * コンストラクタ<br>
	 */
	public OrderHistory() {
		this.historyNum = 0;
		this.orderNum = 0;
		this.id = null;
		this.quantity = 0;
		this.price = 0;
	}

	/**
	 * 購入履歴のナンバーのゲッターセッター
	 */
	public int getHistoryNum() {
		return historyNum;
	}

	public void setHistoryNum(int historyNum) {
		this.historyNum = historyNum;
	}

	/**
	 * 受注ナンバーのゲッターセッター
	 */
	public int getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}

	/**
	 * 商品番号のゲッターセッター
	 */
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	/**
	 * 数量のゲッターセッター
	 */
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * 単価のゲッターセッター
	 */
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}
