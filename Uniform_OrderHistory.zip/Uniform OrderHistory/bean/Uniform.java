/*
 * DAOクラス（管理者情報）
 * 作成日：2022年6月21日
 * 作成者：伊藤瑠玖
 */
package bean;

public class Uniform {
	/**
	 * ユニフォームのID
	 */
	private String id;
	/**
	 * ユニフォームの商品名
	 */
	private String name;
	/**
	 * ユニフォームの単価
	 */
	private int price;
	/**
	 * ユニフォームの在庫数
	 */
	private int stock;

	/**
	 * コンストラクタ<br>
	 * ユニフォーム情報（ID、商品名、単価、在庫数）の初期設定をおこなう
	 */
	public Uniform() {
		this.id = null;
		this.name = null;
		this.price = 0;
		this.stock = 0;
	}

	/**
	 * 商品番号のゲッターセッター
	 */
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	/**
	 * 商品名のゲッターセッター
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 単価のゲッターセッター
	 */
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	/**
	 * 在庫数のゲッターセッター
	 */
	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}
}
