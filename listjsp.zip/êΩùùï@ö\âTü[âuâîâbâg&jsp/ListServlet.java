/*
 * 商品一覧表示機能に関する処理を行うサーブレットクラス
 * 作成日：2022年6月21日
 * 作成者：本多祐香子
 */

package servlet;

import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.Uniform;
import dao.UniformDAO;

public class ListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラー処理用変数の宣言
		String error = "";
		String cmd = "";

		try {
			UniformDAO objUniDao = new UniformDAO();

			ArrayList<Uniform> list = objUniDao.selectAll();
			request.setAttribute("uniform_list", list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "logout";
		} finally {
			if (error.equals("")) {
				// listへフォワード
				request.getRequestDispatcher("/view/list.jsp").forward(request, response);
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}

	}
}
