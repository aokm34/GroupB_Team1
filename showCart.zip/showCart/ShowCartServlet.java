/*
 * カート状況確認機能
 * 作成日：2022年6月22日
 * 作成者：伊藤瑠玖
 */
package servlet;

import java.io.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.*;

public class ShowCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String cmd = "";

		try {

			// � セッションから"user"を取得する
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");

			// セッション切れの場合はerror.jspに遷移する
			if (user == null) {
				error = "セッション切れの為、カート状況は確認出来ません。";
				cmd = "logout";
				return;
			}

			// � delnoの入力パラメータを取得する
			String delno = (String) request.getParameter("delno");

			// � セッションから"order_list"を取得する
			ArrayList<OrderList> order_list = (ArrayList<OrderList>) session
					.getAttribute("order_list");

			// � delnoが「null」でない場合、order_listから該当書籍を削除する
			if (delno != null) {
				order_list.remove(Integer.parseInt(delno));
				session.setAttribute("order_list", order_list);
			}

			// � 取得したOrder_listを、リクエストスコープに"order_list"という名前で格納する
			request.setAttribute("order_list", order_list);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、カート状況は確認出来ません。";
			cmd = "logout";

		} finally {
			// � エラーの有無でフォワード先を呼び分ける
			if (error.equals("")) {
				// エラーが無い場合はshowCart.jspにフォワード
				request.getRequestDispatcher("/view/showCart.jsp").forward(
						request, response);
			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(
						request, response);
			}
		}
	}
}

